const full = new Intl.NumberFormat("en-US");
const compact1 = new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 });
const compact0 = new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 0 });

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export const fmtNum = (n: number) => full.format(Math.round(n));

export function fmtCompact(n: number) {
  const v = Math.abs(n) >= 100_000 ? compact0.format(n) : compact1.format(n);
  return v.replace(".0", "");
}

export const fmtMoney = (n: number) => "$" + full.format(Math.round(n));

export function fmtMoneyCompact(n: number) {
  return Math.abs(n) < 1000 ? "$" + Math.round(n) : "$" + fmtCompact(n);
}

export const fmtPct = (n: number, digits = 2) => `${n.toFixed(digits)}%`;

export const fmtDelta = (n: number) => `${n >= 0 ? "+" : ""}${n.toFixed(1)}%`;

export function fmtDuration(sec: number) {
  if (sec < 60) return `${Math.round(sec)}s`;
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return s > 0 ? `${m}m ${s}s` : `${m}m`;
}

const toDate = (t: number | Date) => (typeof t === "number" ? new Date(t) : t);

export function fmtDate(t: number | Date) {
  const d = toDate(t);
  return `${MONTHS[d.getMonth()]} ${d.getDate()}`;
}

export function fmtDateLong(t: number | Date) {
  const d = toDate(t);
  return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

export function fmtTime(t: number) {
  const d = new Date(t);
  const hh = `${d.getHours()}`.padStart(2, "0");
  const mm = `${d.getMinutes()}`.padStart(2, "0");
  return `${hh}:${mm}`;
}

/** value for <input type="date">, in local time */
export function toISODate(t: number) {
  const d = new Date(t);
  const mm = `${d.getMonth() + 1}`.padStart(2, "0");
  const dd = `${d.getDate()}`.padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

export function pctDelta(cur: number, prev: number) {
  if (prev <= 0) return cur > 0 ? 100 : 0;
  return ((cur - prev) / prev) * 100;
}

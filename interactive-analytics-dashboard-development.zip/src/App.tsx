import { useState } from "react";
import ChannelBar from "./components/ChannelBar";
import DeviceDonut from "./components/DeviceDonut";
import Header from "./components/Header";
import KpiCards from "./components/KpiCards";
import SessionsTable from "./components/SessionsTable";
import Sidebar from "./components/Sidebar";
import TopPages from "./components/TopPages";
import TrafficChart from "./components/TrafficChart";
import { CHANNELS, presetRange, type ChannelId, type DateRange } from "./data/analytics";
import { useAnalytics } from "./hooks/useAnalytics";
import { fmtDate, fmtTime } from "./lib/format";

export default function App() {
  const [theme, setTheme] = useState<"light" | "dark">(() =>
    document.documentElement.classList.contains("dark") ? "dark" : "light"
  );
  const [range, setRange] = useState<DateRange>(() => presetRange("30d"));
  const [channels, setChannels] = useState<ChannelId[]>(CHANNELS.map((c) => c.id));
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    const root = document.documentElement;
    root.classList.add("themed");
    root.classList.toggle("dark", next === "dark");
    try {
      localStorage.setItem("ahad-theme", next);
    } catch {
      /* storage unavailable */
    }
    window.setTimeout(() => root.classList.remove("themed"), 450);
    setTheme(next);
  };

  const toggleChannel = (id: ChannelId) =>
    setChannels((cur) =>
      cur.includes(id) ? (cur.length > 1 ? cur.filter((c) => c !== id) : cur) : [...cur, id]
    );
  const selectAllChannels = () => setChannels(CHANNELS.map((c) => c.id));

  const data = useAnalytics(range.startT, range.endT, channels);

  return (
    <div className="min-h-screen">
      <div className="flex items-start">
        <Sidebar className="sticky top-0 hidden h-screen lg:flex" />

        <div className="flex min-w-0 flex-1 flex-col">
          <Header
            theme={theme}
            onToggleTheme={toggleTheme}
            range={range}
            onRangeChange={setRange}
            channels={channels}
            onToggleChannel={toggleChannel}
            onSelectAllChannels={selectAllChannels}
            onOpenSidebar={() => setMenuOpen(true)}
          />

          <main className="mx-auto w-full max-w-[1400px] space-y-4 px-4 py-6 sm:space-y-5 sm:px-6 lg:px-8">
            <div className="rise flex flex-wrap items-end justify-between gap-3">
              <div>
                <h1 className="font-display text-[22px] font-bold tracking-tight sm:text-2xl">Overview</h1>
                <p className="mt-1 text-[13px] text-muted-foreground">
                  Live performance for <span className="font-semibold text-foreground">ahadorg.onrender.com</span> —{" "}
                  {range.label.toLowerCase()} vs the previous {data.days} days
                </p>
              </div>
              <div className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground shadow-soft">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                {fmtDate(range.startT)} – {fmtDate(range.endT)}
                <span className="text-muted-foreground/50">·</span>
                <span className="tnum">{data.days} days</span>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <KpiCards data={data} delayStart={80} />
            </div>

            <div className="grid grid-cols-1 gap-4 sm:gap-5 xl:grid-cols-3">
              <div className="rise xl:col-span-2" style={{ animationDelay: "220ms" }}>
                <TrafficChart data={data} />
              </div>
              <div className="rise" style={{ animationDelay: "280ms" }}>
                <DeviceDonut data={data} className="h-full" />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:gap-5 xl:grid-cols-3">
              <div className="rise xl:col-span-2" style={{ animationDelay: "340ms" }}>
                <ChannelBar data={data} />
              </div>
              <div className="rise" style={{ animationDelay: "400ms" }}>
                <TopPages rows={data.rows} className="h-full" />
              </div>
            </div>

            <div className="rise" style={{ animationDelay: "460ms" }}>
              <SessionsTable rows={data.rows} />
            </div>
          </main>

          <footer className="mx-auto w-full max-w-[1400px] px-4 pb-8 sm:px-6 lg:px-8">
            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-4 text-xs text-muted-foreground">
              <p>© 2026 ahad·org — demo workspace. Sample dataset generated locally.</p>
              <p className="tnum">Refreshes every 5 min · Last sync {fmtTime(Date.now())}</p>
            </div>
          </footer>
        </div>
      </div>

      {menuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-[2px]"
            onClick={() => setMenuOpen(false)}
            aria-hidden
          />
          <Sidebar
            className="pop-in absolute left-0 top-0 h-full w-[280px] bg-background shadow-lift"
            onClose={() => setMenuOpen(false)}
          />
        </div>
      )}
    </div>
  );
}

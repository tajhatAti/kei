import {
  ArrowDownRight,
  ArrowUpRight,
  MousePointerClick,
  Target,
  Users,
  Wallet,
  type LucideIcon,
} from "lucide-react";
import type { AnalyticsResult } from "../hooks/useAnalytics";
import { fmtCompact, fmtDelta, fmtMoney, fmtPct, pctDelta } from "../lib/format";
import { cn } from "../utils/cn";
import { AnimatedNumber, Sparkline } from "./ChartBits";
import { Card } from "./ui";

function DeltaChip({ delta }: { delta: number }) {
  const up = delta >= 0;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 rounded-full px-2 py-1 text-[11px] font-bold ring-1 ring-inset",
        up
          ? "bg-emerald-500/10 text-emerald-600 ring-emerald-500/20 dark:text-emerald-400"
          : "bg-rose-500/10 text-rose-600 ring-rose-500/20 dark:text-rose-400"
      )}
    >
      {up ? <ArrowUpRight size={12} strokeWidth={2.6} /> : <ArrowDownRight size={12} strokeWidth={2.6} />}
      <span className="tnum">{fmtDelta(delta)}</span>
    </span>
  );
}

interface KpiDef {
  key: string;
  label: string;
  icon: LucideIcon;
  tint: string;
  value: number;
  delta: number;
  format: (n: number) => string;
  spark: number[];
}

export default function KpiCards({ data, delayStart = 0 }: { data: AnalyticsResult; delayStart?: number }) {
  const { totals, prev, spark } = data;
  const defs: KpiDef[] = [
    {
      key: "sessions",
      label: "Total sessions",
      icon: MousePointerClick,
      tint: "#6366f1",
      value: totals.sessions,
      delta: pctDelta(totals.sessions, prev.sessions),
      format: fmtCompact,
      spark: spark.sessions,
    },
    {
      key: "users",
      label: "Unique users",
      icon: Users,
      tint: "#0ea5e9",
      value: totals.users,
      delta: pctDelta(totals.users, prev.users),
      format: fmtCompact,
      spark: spark.users,
    },
    {
      key: "rate",
      label: "Conversion rate",
      icon: Target,
      tint: "#f59e0b",
      value: totals.rate,
      delta: pctDelta(totals.rate, prev.rate),
      format: (n) => fmtPct(n, 2),
      spark: spark.rate,
    },
    {
      key: "revenue",
      label: "Revenue",
      icon: Wallet,
      tint: "#10b981",
      value: totals.revenue,
      delta: pctDelta(totals.revenue, prev.revenue),
      format: fmtMoney,
      spark: spark.revenue,
    },
  ];

  return (
    <>
      {defs.map((d, i) => (
        <Card key={d.key} className="rise p-5" style={{ animationDelay: `${delayStart + i * 70}ms` }}>
          <div className="flex items-start justify-between gap-2">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-xl"
              style={{ background: `${d.tint}1c`, color: d.tint }}
            >
              <d.icon size={18} strokeWidth={2.1} />
            </div>
            <DeltaChip delta={d.delta} />
          </div>
          <p className="mt-4 text-[13px] font-medium text-muted-foreground">{d.label}</p>
          <div className="mt-1 font-display text-[27px] font-semibold leading-none tracking-tight">
            <AnimatedNumber value={d.value} format={d.format} />
          </div>
          <Sparkline data={d.spark} positive={d.delta >= 0} className="mt-4 h-9 w-full" />
          <p className="mt-2 text-[11px] text-muted-foreground">vs previous {data.days} days</p>
        </Card>
      ))}
    </>
  );
}

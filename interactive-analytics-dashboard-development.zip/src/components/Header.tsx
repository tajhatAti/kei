import { useEffect, useState } from "react";
import { Menu, Moon, Sun } from "lucide-react";
import type { ChannelId, DateRange } from "../data/analytics";
import { DateRangeFilter, SegmentFilter } from "./filters";
import { IconButton } from "./ui";

function LivePill() {
  const [n, setN] = useState(126);
  useEffect(() => {
    const id = setInterval(() => {
      setN((v) => Math.min(178, Math.max(86, v + Math.round((Math.random() - 0.48) * 9))));
    }, 2600);
    return () => clearInterval(id);
  }, []);
  return (
    <div
      className="hidden h-9 items-center gap-2 rounded-lg border border-border bg-card px-3 text-[13px] font-medium shadow-soft md:inline-flex"
      title="Visitors on ahadorg.onrender.com right now"
    >
      <span className="relative flex h-2 w-2">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
      </span>
      <span className="tnum font-semibold">{n}</span>
      <span className="text-muted-foreground">live</span>
    </div>
  );
}

interface HeaderProps {
  theme: "light" | "dark";
  onToggleTheme: () => void;
  range: DateRange;
  onRangeChange: (r: DateRange) => void;
  channels: ChannelId[];
  onToggleChannel: (id: ChannelId) => void;
  onSelectAllChannels: () => void;
  onOpenSidebar: () => void;
}

export default function Header({
  theme,
  onToggleTheme,
  range,
  onRangeChange,
  channels,
  onToggleChannel,
  onSelectAllChannels,
  onOpenSidebar,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 w-full max-w-[1400px] items-center gap-2 px-4 sm:px-6 lg:px-8">
        <IconButton label="Open menu" onClick={onOpenSidebar} className="lg:hidden">
          <Menu size={18} />
        </IconButton>

        <div className="hidden leading-tight sm:block">
          <p className="text-[13px] font-semibold">ahadorg.onrender.com</p>
          <p className="text-[11px] text-muted-foreground">Analytics · Overview</p>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <LivePill />
          <DateRangeFilter value={range} onChange={onRangeChange} />
          <SegmentFilter selected={channels} onToggle={onToggleChannel} onSelectAll={onSelectAllChannels} />
          <span className="mx-1 hidden h-5 w-px bg-border sm:block" />
          <IconButton label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"} onClick={onToggleTheme}>
            <span key={theme} className="pop-in inline-flex">
              {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            </span>
          </IconButton>
          <button
            type="button"
            aria-label="Account"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-[11px] font-bold text-white shadow-md shadow-indigo-500/25 transition-transform hover:scale-105 active:scale-95"
          >
            AH
          </button>
        </div>
      </div>
    </header>
  );
}

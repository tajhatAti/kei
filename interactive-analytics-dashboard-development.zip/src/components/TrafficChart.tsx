import { useMemo, useState } from "react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { METRICS, type AnalyticsResult, type ChannelAgg, type MetricKey } from "../hooks/useAnalytics";
import { fmtCompact, fmtMoney, fmtMoneyCompact } from "../lib/format";
import { AnimatedNumber, ChartTooltip } from "./ChartBits";
import { Card, Segmented } from "./ui";

const metricValue = (a: ChannelAgg, m: MetricKey) =>
  m === "sessions" ? a.sessions : m === "users" ? a.users : m === "conversions" ? a.conversions : a.revenue;

export default function TrafficChart({ data, className }: { data: AnalyticsResult; className?: string }) {
  const [metric, setMetric] = useState<MetricKey>("sessions");
  const meta = METRICS.find((m) => m.id === metric)!;
  const rows = data.rowsByMetric[metric];
  const agg = data.channelAgg;
  const format = meta.money ? fmtMoneyCompact : fmtCompact;
  const total = useMemo(() => agg.reduce((s, a) => s + metricValue(a, metric), 0), [agg, metric]);

  return (
    <Card className={className}>
      <div className="flex flex-wrap items-start justify-between gap-3 px-5 pt-5">
        <div>
          <h3 className="font-display text-[15px] font-semibold tracking-tight">Traffic overview</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            <AnimatedNumber
              value={total}
              format={meta.money ? fmtMoney : fmtCompact}
              className="text-[13px] font-semibold text-foreground"
            />{" "}
            {meta.label.toLowerCase()} across {data.days} days
          </p>
        </div>
        <Segmented options={METRICS.map((m) => ({ id: m.id, label: m.label }))} value={metric} onChange={setMetric} />
      </div>

      <div className="flex flex-wrap gap-x-4 gap-y-1.5 px-5 pt-3">
        {agg.map((a) => (
          <span key={a.meta.id} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className="h-2 w-2 rounded-full" style={{ background: a.meta.color }} />
            {a.meta.short}
            <span className="tnum font-semibold text-foreground">{format(metricValue(a, metric))}</span>
          </span>
        ))}
      </div>

      <div className="h-[300px] px-2 pb-4 pt-4 sm:h-[340px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={rows} margin={{ top: 6, right: 14, left: 0, bottom: 0 }}>
            <defs>
              {agg.map((a) => (
                <linearGradient key={a.meta.id} id={`tg-${a.meta.id}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={a.meta.color} stopOpacity={0.22} />
                  <stop offset="100%" stopColor={a.meta.color} stopOpacity={0} />
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid vertical={false} stroke="var(--chart-grid)" />
            <XAxis
              dataKey="label"
              tickLine={false}
              axisLine={false}
              minTickGap={40}
              dy={8}
              tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
            />
            <YAxis
              width={54}
              tickLine={false}
              axisLine={false}
              tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
              tickFormatter={(v: number) => (meta.money ? fmtMoneyCompact(v) : fmtCompact(v))}
            />
            <Tooltip
              content={<ChartTooltip format={format} />}
              cursor={{ stroke: "var(--muted-foreground)", strokeOpacity: 0.25, strokeDasharray: "4 4" }}
            />
            {agg.map((a) => (
              <Area
                key={a.meta.id}
                type="monotone"
                dataKey={a.meta.id}
                name={a.meta.name}
                stroke={a.meta.color}
                strokeWidth={2}
                fill={`url(#tg-${a.meta.id})`}
                dot={false}
                activeDot={{ r: 3.5, strokeWidth: 0 }}
                animationDuration={600}
              />
            ))}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}

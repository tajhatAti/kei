import { useState } from "react";
import { Calendar, Check, ChevronDown, SlidersHorizontal } from "lucide-react";
import {
  CHANNELS,
  DATA_START,
  TODAY,
  presetRange,
  type ChannelId,
  type DateRange,
} from "../data/analytics";
import { fmtDate, toISODate } from "../lib/format";
import { cn } from "../utils/cn";
import { Dropdown, FilterButton } from "./ui";

/* ---------------------------- Date range ---------------------------- */

export function DateRangeFilter({
  value,
  onChange,
}: {
  value: DateRange;
  onChange: (r: DateRange) => void;
}) {
  const [start, setStart] = useState(toISODate(value.startT));
  const [end, setEnd] = useState(toISODate(value.endT));
  const presets = (["7d", "30d", "90d", "12m"] as const).map(presetRange);

  const applyCustom = (close: () => void) => {
    let s = new Date(`${start}T00:00:00`).getTime();
    let e = new Date(`${end}T00:00:00`).getTime();
    if (Number.isNaN(s) || Number.isNaN(e)) return;
    if (s > e) [s, e] = [e, s];
    s = Math.max(s, DATA_START);
    e = Math.min(e, TODAY.getTime());
    onChange({ key: "custom", label: `${fmtDate(s)} – ${fmtDate(e)}`, startT: s, endT: e });
    close();
  };

  const dateInputCls =
    "h-8 w-full min-w-0 rounded-lg border border-border bg-background px-2 text-xs font-medium text-foreground transition-colors focus:border-primary focus:outline-none";

  return (
    <Dropdown
      align="end"
      trigger={
        <FilterButton>
          <Calendar size={14} className="text-muted-foreground" />
          <span className="max-w-[10rem] truncate">{value.label}</span>
          <ChevronDown size={14} className="text-muted-foreground" />
        </FilterButton>
      }
    >
      {(close) => (
        <div className="w-[264px]">
          <p className="px-3 pb-1 pt-2 text-[10.5px] font-bold uppercase tracking-[0.12em] text-muted-foreground/70">
            Range
          </p>
          {presets.map((p) => (
            <button
              key={p.key}
              type="button"
              onClick={() => {
                onChange(p);
                setStart(toISODate(p.startT));
                setEnd(toISODate(p.endT));
                close();
              }}
              className={cn(
                "flex w-full items-center justify-between rounded-lg px-3 py-2 text-[13px] font-medium transition-colors hover:bg-muted",
                value.key === p.key ? "text-foreground" : "text-muted-foreground"
              )}
            >
              {p.label}
              {value.key === p.key && <Check size={15} className="text-primary" />}
            </button>
          ))}

          <div className="my-1.5 h-px bg-border" />
          <p className="px-3 pb-1.5 pt-1 text-[10.5px] font-bold uppercase tracking-[0.12em] text-muted-foreground/70">
            Custom range
          </p>
          <div className="flex items-center gap-1.5 px-3 pb-2">
            <input
              type="date"
              aria-label="Start date"
              value={start}
              min={toISODate(DATA_START)}
              max={toISODate(TODAY.getTime())}
              onChange={(e) => setStart(e.target.value)}
              className={dateInputCls}
            />
            <span className="shrink-0 text-muted-foreground">–</span>
            <input
              type="date"
              aria-label="End date"
              value={end}
              min={toISODate(DATA_START)}
              max={toISODate(TODAY.getTime())}
              onChange={(e) => setEnd(e.target.value)}
              className={dateInputCls}
            />
          </div>
          <div className="px-3 pb-1.5">
            <button
              type="button"
              onClick={() => applyCustom(close)}
              disabled={!start || !end}
              className="w-full rounded-lg bg-primary py-1.5 text-[13px] font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
            >
              Apply range
            </button>
          </div>
        </div>
      )}
    </Dropdown>
  );
}

/* ----------------------------- Segments ----------------------------- */

function SegmentRow({
  label,
  color,
  checked,
  onClick,
}: {
  label: string;
  color?: string;
  checked: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] font-medium text-foreground transition-colors hover:bg-muted"
    >
      <span
        className={cn(
          "flex h-4 w-4 shrink-0 items-center justify-center rounded-[5px] border transition-all",
          checked ? "border-transparent" : "border-border bg-background"
        )}
        style={checked ? { background: color ?? "var(--primary)" } : undefined}
      >
        {checked && <Check size={11} strokeWidth={3.2} className="text-white" />}
      </span>
      {color && <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: color }} />}
      <span className="truncate">{label}</span>
    </button>
  );
}

export function SegmentFilter({
  selected,
  onToggle,
  onSelectAll,
}: {
  selected: ChannelId[];
  onToggle: (id: ChannelId) => void;
  onSelectAll: () => void;
}) {
  const all = selected.length === CHANNELS.length;
  return (
    <Dropdown
      align="end"
      trigger={
        <FilterButton>
          <SlidersHorizontal size={14} className="text-muted-foreground" />
          <span>{all ? "All channels" : `${selected.length} channel${selected.length === 1 ? "" : "s"}`}</span>
          {!all && (
            <span className="flex -space-x-1">
              {CHANNELS.filter((c) => selected.includes(c.id))
                .slice(0, 4)
                .map((c) => (
                  <span
                    key={c.id}
                    className="h-2.5 w-2.5 rounded-full ring-2 ring-card"
                    style={{ background: c.color }}
                  />
                ))}
            </span>
          )}
          <ChevronDown size={14} className="text-muted-foreground" />
        </FilterButton>
      }
    >
      <div className="w-60">
        <p className="px-3 pb-1 pt-2 text-[10.5px] font-bold uppercase tracking-[0.12em] text-muted-foreground/70">
          Channels
        </p>
        <SegmentRow label="All channels" checked={all} onClick={onSelectAll} />
        <div className="my-1 h-px bg-border" />
        {CHANNELS.map((c) => (
          <SegmentRow
            key={c.id}
            label={c.name}
            color={c.color}
            checked={selected.includes(c.id)}
            onClick={() => onToggle(c.id)}
          />
        ))}
        <p className="px-3 pb-1.5 pt-1.5 text-[11px] leading-snug text-muted-foreground/80">
          Every view updates live as you toggle channels.
        </p>
      </div>
    </Dropdown>
  );
}



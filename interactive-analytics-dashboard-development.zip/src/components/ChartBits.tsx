import { useEffect, useRef, useState } from "react";
import { cn } from "../utils/cn";

/* ------------------------- Animated number ------------------------- */

export function AnimatedNumber({
  value,
  format,
  className,
  duration = 650,
}: {
  value: number;
  format: (n: number) => string;
  className?: string;
  duration?: number;
}) {
  const [display, setDisplay] = useState(0);
  const prev = useRef(0);

  useEffect(() => {
    const from = prev.current;
    const to = value;
    const start = performance.now();
    let raf = 0;
    const ease = (x: number) => 1 - Math.pow(1 - x, 3);
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      setDisplay(from + (to - from) * ease(p));
      if (p < 1) {
        raf = requestAnimationFrame(tick);
      } else {
        prev.current = to;
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);

  return <span className={cn("tnum", className)}>{format(display)}</span>;
}

/* --------------------------- Sparkline ----------------------------- */

function smoothPath(pts: [number, number][]) {
  if (pts.length < 2) return "";
  let d = `M ${pts[0][0].toFixed(2)} ${pts[0][1].toFixed(2)}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[Math.min(pts.length - 1, i + 2)];
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C ${c1x.toFixed(2)} ${c1y.toFixed(2)}, ${c2x.toFixed(2)} ${c2y.toFixed(2)}, ${p2[0].toFixed(2)} ${p2[1].toFixed(2)}`;
  }
  return d;
}

export function Sparkline({
  data,
  positive,
  className,
}: {
  data: number[];
  positive: boolean;
  className?: string;
}) {
  const W = 120;
  const H = 34;
  const PAD = 2.5;
  if (data.length < 2) return <div className={className} />;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const pts: [number, number][] = data.map((v, i) => [
    PAD + (i / (data.length - 1)) * (W - PAD * 2),
    PAD + (1 - (v - min) / span) * (H - PAD * 2),
  ]);
  const line = smoothPath(pts);
  const area = `${line} L ${pts[pts.length - 1][0].toFixed(2)} ${H} L ${pts[0][0].toFixed(2)} ${H} Z`;

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="none"
      aria-hidden
      className={cn("block", positive ? "text-emerald-500" : "text-rose-500", className)}
    >
      <path d={area} fill="currentColor" fillOpacity={0.09} stroke="none" />
      <path
        d={line}
        fill="none"
        stroke="currentColor"
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}

/* -------------------------- Chart tooltip -------------------------- */

interface TipEntry {
  name?: string;
  value?: number;
  color?: string;
  fill?: string;
  payload?: Record<string, unknown>;
}

export function ChartTooltip({
  active,
  payload,
  label,
  format,
}: {
  active?: boolean;
  payload?: TipEntry[];
  label?: string | number;
  format: (n: number) => string;
}) {
  if (!active || !payload || payload.length === 0) return null;
  const items = [...payload].sort((a, b) => (b.value ?? 0) - (a.value ?? 0));
  const total = items.reduce((s, p) => s + (typeof p.value === "number" ? p.value : 0), 0);
  return (
    <div className="min-w-[180px] rounded-xl border border-border bg-card/95 px-3.5 py-3 shadow-lift backdrop-blur-md">
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
      <div className="space-y-1.5">
        {items.map((p, i) => (
          <div key={i} className="flex items-center gap-2 text-[13px]">
            <span
              className="h-2 w-2 shrink-0 rounded-full"
              style={{ background: p.color ?? p.fill ?? (p.payload?.fill as string) ?? "var(--primary)" }}
            />
            <span className="truncate text-muted-foreground">{p.name}</span>
            <span className="tnum ml-auto pl-3 font-semibold">{format(p.value ?? 0)}</span>
          </div>
        ))}
      </div>
      {items.length > 1 && (
        <div className="mt-2 flex items-center justify-between border-t border-border pt-2 text-[13px]">
          <span className="font-medium text-muted-foreground">Total</span>
          <span className="tnum font-bold">{format(total)}</span>
        </div>
      )}
    </div>
  );
}

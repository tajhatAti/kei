import { useMemo } from "react";
import type { SessionRow } from "../data/analytics";
import { fmtCompact, fmtMoney } from "../lib/format";
import { Card, CardTitle } from "./ui";

export default function TopPages({ rows, className }: { rows: SessionRow[]; className?: string }) {
  const pages = useMemo(() => {
    const map = new Map<string, { page: string; views: number; revenue: number }>();
    for (const r of rows) {
      const e = map.get(r.page) ?? { page: r.page, views: 0, revenue: 0 };
      e.views += 1;
      e.revenue += r.revenue;
      map.set(r.page, e);
    }
    return [...map.values()].sort((a, b) => b.views - a.views).slice(0, 6);
  }, [rows]);
  const max = pages[0]?.views ?? 1;

  return (
    <Card className={className}>
      <div className="px-5 pt-5">
        <CardTitle title="Top pages" subtitle="Most visited destinations in the current range" />
      </div>
      <div className="px-3 pb-4 pt-2">
        {pages.map((p, i) => (
          <div
            key={p.page}
            className="group flex items-center gap-3 rounded-lg px-2 py-2.5 transition-colors hover:bg-muted"
          >
            <span className="tnum w-6 shrink-0 font-mono text-[11px] font-semibold text-muted-foreground/70">
              {String(i + 1).padStart(2, "0")}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate font-mono text-xs font-medium text-foreground">{p.page}</p>
              <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-[width] duration-700 ease-out"
                  style={{ width: `${(p.views / max) * 100}%` }}
                />
              </div>
            </div>
            <div className="shrink-0 text-right leading-tight">
              <p className="tnum text-[13px] font-semibold">{fmtCompact(p.views)}</p>
              <p className="tnum mt-0.5 text-[11px] text-muted-foreground">{fmtMoney(p.revenue)}</p>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

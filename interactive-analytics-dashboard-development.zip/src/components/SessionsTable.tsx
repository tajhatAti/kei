import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Download,
  Monitor,
  Search,
  Smartphone,
  Tablet,
  type LucideIcon,
} from "lucide-react";
import { CHANNEL_MAP, type DeviceId, type SessionRow, type SessionStatus } from "../data/analytics";
import { fmtCompact, fmtDate, fmtDuration, fmtMoney, fmtNum, fmtTime, toISODate } from "../lib/format";
import { cn } from "../utils/cn";
import { Card } from "./ui";

const PAGE_SIZE = 8;

const STATUS_STYLE: Record<SessionStatus, string> = {
  converted: "bg-emerald-500/10 text-emerald-600 ring-emerald-500/25 dark:text-emerald-400",
  engaged: "bg-sky-500/10 text-sky-600 ring-sky-500/25 dark:text-sky-400",
  bounced: "bg-zinc-500/10 text-zinc-500 ring-zinc-500/20 dark:text-zinc-400",
};
const STATUS_LABEL: Record<SessionStatus, string> = {
  converted: "Converted",
  engaged: "Engaged",
  bounced: "Bounced",
};
const DEVICE_ICON: Record<DeviceId, LucideIcon> = { desktop: Monitor, mobile: Smartphone, tablet: Tablet };

function hashHue(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
  return h;
}

interface Col {
  key: string;
  label: string;
  hide?: string;
  alignRight?: boolean;
  sortValue: (r: SessionRow) => number | string;
  render: (r: SessionRow) => ReactNode;
}

const COLUMNS: Col[] = [
  {
    key: "name",
    label: "User",
    sortValue: (r) => r.name,
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <span
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[10px] font-bold text-white"
          style={{ background: `hsl(${hashHue(r.name)} 62% 46%)` }}
        >
          {r.initials}
        </span>
        <span className="max-w-[11rem] truncate font-medium">{r.name}</span>
      </div>
    ),
  },
  {
    key: "channel",
    label: "Channel",
    sortValue: (r) => CHANNEL_MAP[r.channel].name,
    render: (r) => (
      <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
        <span className="h-2 w-2 rounded-full" style={{ background: CHANNEL_MAP[r.channel].color }} />
        {CHANNEL_MAP[r.channel].short}
      </span>
    ),
  },
  {
    key: "device",
    label: "Device",
    hide: "hidden md:table-cell",
    sortValue: (r) => r.device,
    render: (r) => {
      const Icon = DEVICE_ICON[r.device];
      return (
        <span className="inline-flex items-center gap-1.5 text-muted-foreground">
          <Icon size={14} />
          <span className="hidden capitalize lg:inline">{r.device}</span>
        </span>
      );
    },
  },
  {
    key: "country",
    label: "Location",
    hide: "hidden xl:table-cell",
    sortValue: (r) => r.country,
    render: (r) => <span className="text-muted-foreground">{r.country}</span>,
  },
  {
    key: "page",
    label: "Landing page",
    hide: "hidden lg:table-cell",
    sortValue: (r) => r.page,
    render: (r) => <span className="font-mono text-xs text-muted-foreground">{r.page}</span>,
  },
  {
    key: "pages",
    label: "Pages",
    hide: "hidden lg:table-cell",
    alignRight: true,
    sortValue: (r) => r.pages,
    render: (r) => <span className="tnum">{r.pages}</span>,
  },
  {
    key: "duration",
    label: "Duration",
    hide: "hidden sm:table-cell",
    alignRight: true,
    sortValue: (r) => r.duration,
    render: (r) => <span className="tnum text-muted-foreground">{fmtDuration(r.duration)}</span>,
  },
  {
    key: "revenue",
    label: "Revenue",
    alignRight: true,
    sortValue: (r) => r.revenue,
    render: (r) =>
      r.revenue > 0 ? (
        <span className="tnum font-semibold">{fmtMoney(r.revenue)}</span>
      ) : (
        <span className="text-muted-foreground/50">–</span>
      ),
  },
  {
    key: "status",
    label: "Status",
    sortValue: (r) => STATUS_LABEL[r.status],
    render: (r) => (
      <span
        className={cn(
          "inline-flex items-center whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1 ring-inset",
          STATUS_STYLE[r.status]
        )}
      >
        {STATUS_LABEL[r.status]}
      </span>
    ),
  },
  {
    key: "t",
    label: "Date",
    sortValue: (r) => r.t,
    render: (r) => (
      <div className="whitespace-nowrap leading-tight">
        <p className="font-medium">{fmtDate(r.t)}</p>
        <p className="tnum mt-0.5 text-[11px] text-muted-foreground">{fmtTime(r.t)}</p>
      </div>
    ),
  },
];

const TEXT_SORT_KEYS = new Set(["name", "channel", "device", "country", "page", "status"]);

export default function SessionsTable({ rows, className }: { rows: SessionRow[]; className?: string }) {
  const [query, setQuery] = useState("");
  const [sortKey, setSortKey] = useState("t");
  const [sortDir, setSortDir] = useState<1 | -1>(-1);
  const [page, setPage] = useState(1);

  useEffect(() => {
    setPage(1);
  }, [query, rows]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter(
      (r) =>
        r.name.toLowerCase().includes(q) ||
        r.country.toLowerCase().includes(q) ||
        r.page.toLowerCase().includes(q) ||
        r.device.includes(q) ||
        STATUS_LABEL[r.status].toLowerCase().includes(q) ||
        CHANNEL_MAP[r.channel].name.toLowerCase().includes(q)
    );
  }, [rows, query]);

  const sorted = useMemo(() => {
    const col = COLUMNS.find((c) => c.key === sortKey) ?? COLUMNS[COLUMNS.length - 1];
    return [...filtered].sort((a, b) => {
      const va = col.sortValue(a);
      const vb = col.sortValue(b);
      const cmp =
        typeof va === "number" && typeof vb === "number" ? va - vb : String(va).localeCompare(String(vb));
      return cmp * sortDir;
    });
  }, [filtered, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const start = (safePage - 1) * PAGE_SIZE;
  const visible = sorted.slice(start, start + PAGE_SIZE);

  const toggleSort = (key: string) => {
    if (key === sortKey) {
      setSortDir((d) => (d === 1 ? -1 : 1));
    } else {
      setSortKey(key);
      setSortDir(TEXT_SORT_KEYS.has(key) ? 1 : -1);
    }
  };

  const exportCsv = () => {
    const head = ["Date", "User", "Channel", "Device", "Country", "Landing page", "Pages", "Duration", "Revenue (USD)", "Status"];
    const body = sorted.map((r) => [
      new Date(r.t).toISOString(),
      `"${r.name.replace(/"/g, '""')}"`,
      CHANNEL_MAP[r.channel].name,
      r.device,
      `"${r.country}"`,
      r.page,
      String(r.pages),
      fmtDuration(r.duration),
      String(r.revenue),
      STATUS_LABEL[r.status],
    ]);
    const csv = [head, ...body].map((l) => l.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ahad-sessions-${toISODate(Date.now())}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className={className}>
      <div className="flex flex-wrap items-center gap-3 px-5 pb-4 pt-5">
        <div>
          <h3 className="font-display text-[15px] font-semibold tracking-tight">Recent sessions</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            <span className="tnum font-semibold text-foreground">{fmtCompact(filtered.length)}</span> sessions match
            the current filters
          </p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <div className="relative">
            <Search
              size={14}
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search user, page, location…"
              className="h-9 w-full rounded-lg border border-border bg-background pl-9 pr-3 text-[13px] transition-colors placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none sm:w-60"
            />
          </div>
          <button
            type="button"
            onClick={exportCsv}
            className="inline-flex h-9 items-center gap-2 rounded-lg border border-border bg-card px-3 text-[13px] font-medium shadow-soft transition-colors hover:bg-muted"
          >
            <Download size={14} />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[880px] border-collapse text-[13px]">
          <thead>
            <tr className="border-y border-border bg-muted/40">
              {COLUMNS.map((c) => {
                const isActive = sortKey === c.key;
                return (
                  <th key={c.key} className={cn("px-3 py-2.5 font-medium", c.alignRight ? "text-right" : "text-left", c.hide)}>
                    <button
                      type="button"
                      onClick={() => toggleSort(c.key)}
                      className={cn(
                        "group inline-flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wider transition-colors",
                        isActive ? "text-foreground" : "text-muted-foreground hover:text-foreground",
                        c.alignRight && "flex-row-reverse"
                      )}
                    >
                      {c.label}
                      {isActive ? (
                        sortDir === 1 ? (
                          <ArrowUp size={11} className="text-primary" />
                        ) : (
                          <ArrowDown size={11} className="text-primary" />
                        )
                      ) : (
                        <ArrowUpDown size={11} className="opacity-40 transition-opacity group-hover:opacity-80" />
                      )}
                    </button>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {visible.map((r) => (
              <tr key={r.id} className="border-t border-border transition-colors first:border-0 hover:bg-muted/50">
                {COLUMNS.map((c) => (
                  <td key={c.key} className={cn("px-3 py-3", c.alignRight && "text-right", c.hide)}>
                    {c.render(r)}
                  </td>
                ))}
              </tr>
            ))}
            {visible.length === 0 && (
              <tr>
                <td colSpan={COLUMNS.length} className="px-3 py-12 text-center text-muted-foreground">
                  No sessions match your filters. Try widening the date range or clearing the search.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-5 py-3.5">
        <p className="text-xs text-muted-foreground">
          Showing <span className="tnum font-semibold text-foreground">{sorted.length === 0 ? 0 : start + 1}</span>
          {" – "}
          <span className="tnum font-semibold text-foreground">{Math.min(start + PAGE_SIZE, sorted.length)}</span> of{" "}
          <span className="tnum font-semibold text-foreground">{fmtNum(sorted.length)}</span>
        </p>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            aria-label="Previous page"
            disabled={safePage <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-border bg-card text-muted-foreground shadow-soft transition-all hover:bg-muted hover:text-foreground disabled:opacity-40 disabled:hover:bg-card"
          >
            <ChevronLeft size={15} />
          </button>
          <span className="tnum px-1.5 text-xs text-muted-foreground">
            Page {safePage} of {totalPages}
          </span>
          <button
            type="button"
            aria-label="Next page"
            disabled={safePage >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-border bg-card text-muted-foreground shadow-soft transition-all hover:bg-muted hover:text-foreground disabled:opacity-40 disabled:hover:bg-card"
          >
            <ChevronRight size={15} />
          </button>
        </div>
      </div>
    </Card>
  );
}

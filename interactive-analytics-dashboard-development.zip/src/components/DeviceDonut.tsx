import { useMemo, useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Sector, Tooltip, type PieSectorDataItem } from "recharts";
import type { AnalyticsResult } from "../hooks/useAnalytics";
import { fmtCompact, fmtPct } from "../lib/format";
import { AnimatedNumber, ChartTooltip } from "./ChartBits";
import { Card, CardTitle } from "./ui";

export default function DeviceDonut({ data, className }: { data: AnalyticsResult; className?: string }) {
  const devices = data.devices;
  const [active, setActive] = useState<number | null>(null);
  const total = useMemo(() => devices.reduce((s, d) => s + d.value, 0), [devices]);
  const center = active != null ? devices[active] : null;

  return (
    <Card className={className}>
      <div className="px-5 pt-5">
        <CardTitle title="Sessions by device" subtitle="Share of sessions in the selected range" />
      </div>

      <div className="relative mx-auto mt-2 h-[210px] w-full max-w-[250px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={devices}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              innerRadius="68%"
              outerRadius="88%"
              paddingAngle={3}
              cornerRadius={6}
              strokeWidth={0}
              startAngle={90}
              endAngle={-270}
              activeShape={(p: PieSectorDataItem) => (
                <Sector {...p} outerRadius={(p.outerRadius ?? 0) + 6} cornerRadius={7} />
              )}
              onMouseEnter={(_, i) => setActive(i)}
              onMouseLeave={() => setActive(null)}
              animationDuration={650}
            >
              {devices.map((d, i) => (
                <Cell
                  key={d.id}
                  fill={d.color}
                  fillOpacity={active === null || active === i ? 1 : 0.28}
                  style={{ transition: "fill-opacity 0.25s ease" }}
                />
              ))}
            </Pie>
            <Tooltip content={<ChartTooltip format={fmtCompact} />} />
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          {center ? (
            <>
              <p className="tnum font-display text-[26px] font-bold leading-none tracking-tight">
                {fmtPct(center.pct, 1)}
              </p>
              <p className="mt-1.5 text-xs font-medium text-muted-foreground">
                {center.name} · {fmtCompact(center.value)}
              </p>
            </>
          ) : (
            <>
              <p className="font-display text-[26px] font-bold leading-none tracking-tight">
                <AnimatedNumber value={total} format={fmtCompact} />
              </p>
              <p className="mt-1.5 text-xs font-medium text-muted-foreground">Total sessions</p>
            </>
          )}
        </div>
      </div>

      <div className="space-y-0.5 px-4 pb-5 pt-2">
        {devices.map((d, i) => (
          <button
            key={d.id}
            type="button"
            onMouseEnter={() => setActive(i)}
            onMouseLeave={() => setActive(null)}
            onFocus={() => setActive(i)}
            onBlur={() => setActive(null)}
            className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-muted"
          >
            <span className="h-2.5 w-2.5 shrink-0 rounded-[4px]" style={{ background: d.color }} />
            <span className="text-[13px] font-medium">{d.name}</span>
            <span className="tnum ml-auto text-[13px] font-semibold">{fmtCompact(d.value)}</span>
            <span className="tnum w-12 text-right text-xs text-muted-foreground">{fmtPct(d.pct, 1)}</span>
          </button>
        ))}
      </div>
    </Card>
  );
}

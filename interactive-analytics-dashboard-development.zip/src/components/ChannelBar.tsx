import { useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { AnalyticsResult } from "../hooks/useAnalytics";
import { fmtCompact, fmtMoney, fmtMoneyCompact, fmtPct } from "../lib/format";
import { ChartTooltip } from "./ChartBits";
import { Card, CardTitle, Segmented } from "./ui";

type BarMetric = "conversions" | "revenue";

export default function ChannelBar({ data, className }: { data: AnalyticsResult; className?: string }) {
  const [m, setM] = useState<BarMetric>("conversions");
  const money = m === "revenue";
  const rows = [...data.channelAgg]
    .sort((a, b) => b[m] - a[m])
    .map((a) => ({ name: a.meta.short, value: a[m], color: a.meta.color }));

  return (
    <Card className={className}>
      <div className="px-5 pt-5">
        <CardTitle
          title="Channel performance"
          subtitle={`${money ? "Revenue" : "Conversions"} by acquisition channel`}
          right={
            <Segmented
              options={[
                { id: "conversions", label: "Conversions" },
                { id: "revenue", label: "Revenue" },
              ]}
              value={m}
              onChange={setM}
            />
          }
        />
      </div>

      <div className="h-[260px] px-2 pb-2 pt-4">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={rows} margin={{ top: 14, right: 14, left: 0, bottom: 0 }} barCategoryGap="28%">
            <CartesianGrid vertical={false} stroke="var(--chart-grid)" />
            <XAxis
              dataKey="name"
              tickLine={false}
              axisLine={false}
              interval={0}
              dy={8}
              tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
            />
            <YAxis
              width={50}
              tickLine={false}
              axisLine={false}
              tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
              tickFormatter={(v: number) => (money ? fmtMoneyCompact(v) : fmtCompact(v))}
            />
            <Tooltip
              cursor={{ fill: "var(--muted)", fillOpacity: 0.55 }}
              content={<ChartTooltip format={money ? fmtMoney : fmtCompact} />}
            />
            <Bar
              dataKey="value"
              name={money ? "Revenue" : "Conversions"}
              radius={[7, 7, 3, 3]}
              maxBarSize={64}
              animationDuration={600}
            >
              {rows.map((r) => (
                <Cell key={r.name} fill={r.color} />
              ))}
              <LabelList
                dataKey="value"
                position="top"
                formatter={(v: unknown) => (money ? fmtMoneyCompact(Number(v)) : fmtCompact(Number(v)))}
                style={{ fill: "var(--muted-foreground)", fontSize: 11, fontWeight: 600 }}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="flex flex-wrap gap-x-4 gap-y-1.5 border-t border-border px-5 py-3.5">
        {data.channelAgg.map((a) => (
          <span key={a.meta.id} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className="h-2 w-2 rounded-full" style={{ background: a.meta.color }} />
            {a.meta.short}
            <span className="tnum font-semibold text-foreground">{fmtPct(a.rate, 1)}</span> CVR
          </span>
        ))}
      </div>
    </Card>
  );
}

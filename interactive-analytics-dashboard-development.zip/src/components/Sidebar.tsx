import {
  Activity,
  BarChart3,
  Blocks,
  ExternalLink,
  FileText,
  Globe,
  LayoutDashboard,
  Settings,
  Target,
  TrendingUp,
  Users,
  X,
  type LucideIcon,
} from "lucide-react";
import { cn } from "../utils/cn";
import { IconButton } from "./ui";

function NavItem({
  icon: Icon,
  label,
  active,
  badge,
}: {
  icon: LucideIcon;
  label: string;
  active?: boolean;
  badge?: string;
}) {
  return (
    <button
      type="button"
      className={cn(
        "group flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] font-medium transition-all",
        active
          ? "bg-muted text-foreground shadow-soft"
          : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
      )}
    >
      <Icon size={16} strokeWidth={active ? 2.2 : 1.9} className={cn("shrink-0", active && "text-primary")} />
      <span className="truncate">{label}</span>
      {badge && (
        <span className="ml-auto rounded-md bg-primary/10 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-primary">
          {badge}
        </span>
      )}
      {active && !badge && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-primary" />}
    </button>
  );
}

function NavSection({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-1.5 px-3 text-[10.5px] font-bold uppercase tracking-[0.12em] text-muted-foreground/70">
        {label}
      </p>
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}

export default function Sidebar({ className, onClose }: { className?: string; onClose?: () => void }) {
  return (
    <aside
      className={cn(
        "flex w-[272px] shrink-0 flex-col gap-5 overflow-y-auto border-r border-border bg-background px-4 py-5",
        className
      )}
    >
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 text-white shadow-md shadow-indigo-500/25">
            <Activity size={17} strokeWidth={2.4} />
          </div>
          <div>
            <p className="font-display text-[15px] font-bold leading-none tracking-tight">
              ahad<span className="text-muted-foreground">·org</span>
            </p>
            <p className="mt-1 text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">
              Analytics Suite
            </p>
          </div>
        </div>
        {onClose && (
          <IconButton label="Close menu" onClick={onClose} className="lg:hidden">
            <X size={16} />
          </IconButton>
        )}
      </div>

      <a
        href="https://ahadorg.onrender.com"
        target="_blank"
        rel="noreferrer"
        className="group flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-xs font-medium shadow-soft transition-colors hover:bg-muted"
      >
        <Globe size={13} className="shrink-0 text-primary" />
        <span className="truncate">ahadorg.onrender.com</span>
        <ExternalLink size={12} className="ml-auto shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
      </a>

      <nav className="flex-1 space-y-5">
        <NavSection label="General">
          <NavItem icon={LayoutDashboard} label="Overview" active />
          <NavItem icon={TrendingUp} label="Traffic" />
          <NavItem icon={Users} label="Audience" />
          <NavItem icon={FileText} label="Content" />
          <NavItem icon={Target} label="Conversions" />
        </NavSection>
        <NavSection label="Workspace">
          <NavItem icon={BarChart3} label="Reports" badge="New" />
          <NavItem icon={Blocks} label="Integrations" />
          <NavItem icon={Settings} label="Settings" />
        </NavSection>
      </nav>

      <div className="space-y-3">
        <div className="rounded-xl border border-border bg-gradient-to-b from-muted/70 to-transparent p-3.5">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold">Growth plan</p>
            <span className="rounded-md bg-primary/10 px-1.5 py-0.5 text-[10px] font-bold text-primary">82%</span>
          </div>
          <p className="mt-1 text-[11px] text-muted-foreground">41.2k of 50k events used</p>
          <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-muted-foreground/15">
            <div className="h-full w-[82%] rounded-full bg-gradient-to-r from-indigo-500 to-violet-500" />
          </div>
          <button
            type="button"
            className="mt-3 w-full rounded-lg bg-primary py-1.5 text-xs font-semibold text-primary-foreground shadow-sm transition-opacity hover:opacity-90"
          >
            Upgrade to Scale
          </button>
        </div>

        <div className="flex items-center gap-2.5 rounded-xl px-1 py-1">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-[11px] font-bold text-white">
            AH
          </div>
          <div className="min-w-0 flex-1 leading-tight">
            <p className="truncate text-[13px] font-semibold">Ahad Raza</p>
            <p className="truncate text-[11px] text-muted-foreground">Owner · admin@ahadorg.com</p>
          </div>
        </div>
      </div>
    </aside>
  );
}

/* ------------------------------------------------------------------ */
/*  Deterministic sample-data engine for ahadorg.onrender.com          */
/*  Seeded RNG keeps every reload + SSR render identical.              */
/* ------------------------------------------------------------------ */

function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rng = mulberry32(0xa9a1ce);
/** approx normal in [-1, 1], sd ≈ 0.29 */
const gauss = () => (rng() + rng() + rng() + rng() - 2) / 2;
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

export const DAY_MS = 86_400_000;
const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
export const TODAY = startOfDay(new Date());
/** 900 days of history so a "12 months" view always has a full comparison period */
export const DAYS = 900;
export const DATA_START = TODAY.getTime() - (DAYS - 1) * DAY_MS;

/* ------------------------------ meta ------------------------------ */

export type ChannelId = "organic" | "paid" | "social" | "email" | "referral";
export type DeviceId = "desktop" | "mobile" | "tablet";

export interface ChannelMeta {
  id: ChannelId;
  name: string;
  short: string;
  color: string;
}

export const CHANNELS: ChannelMeta[] = [
  { id: "organic", name: "Organic Search", short: "Organic", color: "#6366f1" },
  { id: "paid", name: "Paid Ads", short: "Paid", color: "#f59e0b" },
  { id: "social", name: "Social", short: "Social", color: "#ec4899" },
  { id: "email", name: "Email", short: "Email", color: "#10b981" },
  { id: "referral", name: "Referral", short: "Referral", color: "#0ea5e9" },
];

export const CHANNEL_MAP = Object.fromEntries(CHANNELS.map((c) => [c.id, c])) as Record<ChannelId, ChannelMeta>;

export const DEVICES: { id: DeviceId; name: string; color: string }[] = [
  { id: "desktop", name: "Desktop", color: "#6366f1" },
  { id: "mobile", name: "Mobile", color: "#f59e0b" },
  { id: "tablet", name: "Tablet", color: "#94a3b8" },
];

interface ChannelParams {
  base: number;
  growth: number;
  weekend: number;
  conv: number;
  aov: number;
  spike: number;
  mix: Record<DeviceId, number>;
}

const PARAMS: Record<ChannelId, ChannelParams> = {
  organic: { base: 5200, growth: 0.00012, weekend: -0.16, conv: 0.031, aov: 54, spike: 0.006, mix: { desktop: 0.52, mobile: 0.41, tablet: 0.07 } },
  paid: { base: 3350, growth: 0.0002, weekend: -0.04, conv: 0.024, aov: 88, spike: 0.022, mix: { desktop: 0.44, mobile: 0.49, tablet: 0.07 } },
  social: { base: 2475, growth: 0.00016, weekend: 0.24, conv: 0.015, aov: 42, spike: 0.034, mix: { desktop: 0.22, mobile: 0.74, tablet: 0.04 } },
  email: { base: 1290, growth: 0.00009, weekend: -0.26, conv: 0.047, aov: 61, spike: 0.013, mix: { desktop: 0.47, mobile: 0.46, tablet: 0.07 } },
  referral: { base: 860, growth: 0.00006, weekend: -0.1, conv: 0.021, aov: 49, spike: 0.005, mix: { desktop: 0.55, mobile: 0.38, tablet: 0.07 } },
};

/* ------------------------- daily time series ----------------------- */

export interface DailyRecord {
  t: number; // midnight ms
  channel: ChannelId;
  sessions: number;
  users: number;
  conversions: number;
  revenue: number;
  desktop: number;
  mobile: number;
  tablet: number;
}

export const DAILY: DailyRecord[] = (() => {
  const out: DailyRecord[] = [];
  for (let i = 0; i < DAYS; i++) {
    const t = DATA_START + i * DAY_MS;
    const dow = new Date(t).getDay();
    const isWeekend = dow === 0 || dow === 6;
    const wave = Math.sin((i / 7) * Math.PI * 2) * 0.035; // gentle intra-week wave
    const monthWave = Math.sin((i / 30.4) * Math.PI * 2 + 1.2) * 0.04; // seasonal drift
    for (const ch of CHANNELS) {
      const p = PARAMS[ch.id];
      const season = 1 + p.weekend * (isWeekend ? 1 : 0) + wave + monthWave;
      const trend = 1 + p.growth * i;
      const spike = rng() < p.spike ? 1.25 + rng() * 1.3 : 1;
      const noise = 1 + gauss() * 0.16;
      const sessions = Math.max(24, Math.round(p.base * season * trend * noise * spike));
      const users = Math.round(sessions * (0.66 + rng() * 0.12));
      const conversions = Math.max(1, Math.round(sessions * p.conv * clamp(1 + gauss() * 0.14, 0.5, 1.7)));
      const revenue = Math.round(conversions * p.aov * clamp(0.85 + rng() * 0.4, 0.55, 1.6));
      const rd = clamp(p.mix.desktop + gauss() * 0.04, 0.05, 0.95);
      const rm = clamp(p.mix.mobile + gauss() * 0.04, 0.05, 0.95);
      const rt = clamp(p.mix.tablet + gauss() * 0.015, 0.01, 0.3);
      const tot = rd + rm + rt;
      out.push({
        t,
        channel: ch.id,
        sessions,
        users,
        conversions,
        revenue,
        desktop: Math.round((sessions * rd) / tot),
        mobile: Math.round((sessions * rm) / tot),
        tablet: Math.round((sessions * rt) / tot),
      });
    }
  }
  return out;
})();

/* --------------------------- session rows -------------------------- */

export type SessionStatus = "converted" | "engaged" | "bounced";

export interface SessionRow {
  id: number;
  t: number;
  name: string;
  initials: string;
  channel: ChannelId;
  device: DeviceId;
  country: string;
  page: string;
  pages: number;
  duration: number; // seconds
  revenue: number;
  status: SessionStatus;
}

const NAMES = [
  "Amara Chen", "Lucas Meyer", "Priya Sharma", "Mateo Alvarez", "Sofia Rossi",
  "Noah Kim", "Fatima Al-Sayed", "Ava Novak", "Omar Haddad", "Elena Petrova",
  "Daniel Osei", "Mia Tanaka", "Lucas Silva", "Zara Ahmed", "Ethan Brown",
  "Lina Haddad", "Gabriel Costa", "Nora Lindqvist", "Ivan Petrov", "Jade Nguyen",
  "Samuel Adeyemi", "Clara Fontaine", "Ravi Patel", "Hannah Schmidt", "Yuki Mori",
  "Isabella Romano", "Felix Wagner", "Aisha Bello", "Tomás Silva", "Ingrid Sorensen",
  "David Kim", "Leila Mansour", "Oscar Nilsson", "Aya Nakamura", "Jonas Weber",
  "Ruby Okafor", "Alice Moreau", "Kai Tan", "Marcus Reed", "Elsa Berg",
];

const COUNTRIES: [string, number][] = [
  ["United States", 30], ["United Kingdom", 12], ["India", 12], ["Germany", 10],
  ["Canada", 7], ["Brazil", 6], ["France", 6], ["Australia", 5],
  ["Japan", 5], ["Netherlands", 4], ["Spain", 3],
];

const PAGES: [string, number][] = [
  ["/", 22], ["/pricing", 14], ["/features", 12], ["/docs/getting-started", 9],
  ["/blog/design-system-2-0", 8], ["/templates", 8], ["/signup", 8], ["/integrations", 6],
  ["/case-studies/nimbus", 5], ["/changelog", 5], ["/api-reference", 3],
];

function pickWeighted<T>(entries: [T, number][], r: number): T {
  const total = entries.reduce((s, e) => s + e[1], 0);
  let acc = r * total;
  for (const [v, w] of entries) {
    acc -= w;
    if (acc <= 0) return v;
  }
  return entries[entries.length - 1][0];
}

export const ROWS: SessionRow[] = (() => {
  const out: SessionRow[] = [];
  const channelW = CHANNELS.map((c) => [c.id, PARAMS[c.id].base] as [ChannelId, number]);
  for (let i = 0; i < 4200; i++) {
    const channel = pickWeighted(channelW, rng());
    const p = PARAMS[channel];
    const name = NAMES[Math.floor(rng() * NAMES.length)];
    const dayIdx = Math.floor(DAYS * Math.pow(rng(), 1.6)); // bias to recent days
    const t = DATA_START + dayIdx * DAY_MS + Math.floor((7 + rng() * 14) * 3_600_000);
    const device = pickWeighted(
      [["desktop", p.mix.desktop], ["mobile", p.mix.mobile], ["tablet", p.mix.tablet]] as [DeviceId, number][],
      rng()
    );
    const converted = rng() < Math.min(0.3, p.conv * 5.5);
    const engaged = !converted && rng() < 0.48;
    const status: SessionStatus = converted ? "converted" : engaged ? "engaged" : "bounced";
    const pages = converted ? 5 + Math.floor(rng() * 9) : engaged ? 3 + Math.floor(rng() * 5) : 1 + (rng() < 0.35 ? 1 : 0);
    const duration = converted ? Math.round(240 + rng() * 600) : engaged ? Math.round(80 + rng() * 240) : Math.round(9 + rng() * 42);
    const revenue = converted ? Math.round(p.aov * (0.6 + rng() * 1.1)) : 0;
    out.push({
      id: i + 1,
      t,
      name,
      initials: name.split(" ").map((w) => w[0]).slice(0, 2).join(""),
      channel,
      device,
      country: pickWeighted(COUNTRIES, rng()),
      page: pickWeighted(PAGES, rng()),
      pages,
      duration,
      revenue,
      status,
    });
  }
  return out;
})();

/* --------------------------- date ranges --------------------------- */

export type RangeKey = "7d" | "30d" | "90d" | "12m" | "custom";

export interface DateRange {
  key: RangeKey;
  label: string;
  startT: number;
  endT: number;
}

export function presetRange(key: Exclude<RangeKey, "custom">): DateRange {
  const spans: Record<typeof key, { label: string; days: number }> = {
    "7d": { label: "Last 7 days", days: 7 },
    "30d": { label: "Last 30 days", days: 30 },
    "90d": { label: "Last 90 days", days: 90 },
    "12m": { label: "Last 12 months", days: 365 },
  };
  const { label, days } = spans[key];
  return { key, label, startT: TODAY.getTime() - (days - 1) * DAY_MS, endT: TODAY.getTime() };
}

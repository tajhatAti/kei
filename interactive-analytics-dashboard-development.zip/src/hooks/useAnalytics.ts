import { useMemo } from "react";
import {
  CHANNEL_MAP,
  DAILY,
  DAY_MS,
  DEVICES,
  ROWS,
  type ChannelId,
  type ChannelMeta,
  type DeviceId,
  type SessionRow,
} from "../data/analytics";
import { fmtDate } from "../lib/format";

export type MetricKey = "sessions" | "users" | "conversions" | "revenue";

export const METRICS: { id: MetricKey; label: string; money?: boolean }[] = [
  { id: "sessions", label: "Sessions" },
  { id: "users", label: "Users" },
  { id: "conversions", label: "Conversions" },
  { id: "revenue", label: "Revenue", money: true },
];

export interface Totals {
  sessions: number;
  users: number;
  conversions: number;
  revenue: number;
  rate: number;
}

export interface ChartRow {
  label: string;
  t: number;
  [k: string]: number | string;
}

export interface ChannelAgg {
  meta: ChannelMeta;
  sessions: number;
  users: number;
  conversions: number;
  revenue: number;
  rate: number;
  share: number;
}

export interface DeviceAgg {
  id: DeviceId;
  name: string;
  color: string;
  value: number;
  pct: number;
}

export interface AnalyticsResult {
  days: number;
  totals: Totals;
  prev: Totals;
  spark: { sessions: number[]; users: number[]; rate: number[]; revenue: number[] };
  rowsByMetric: Record<MetricKey, ChartRow[]>;
  channelAgg: ChannelAgg[];
  devices: DeviceAgg[];
  rows: SessionRow[];
}

function blankTotals(): Totals {
  return { sessions: 0, users: 0, conversions: 0, revenue: 0, rate: 0 };
}

function compute(startT: number, endT: number, channels: ChannelId[]): AnalyticsResult {
  const selected = new Set(channels);
  const lenMs = endT - startT + DAY_MS;
  const prevStart = startT - lenMs;
  const endExclusive = endT + DAY_MS;

  const totals = blankTotals();
  const prev = blankTotals();

  // ordered list of days that fall in the range
  const dayList: number[] = [];
  for (const r of DAILY) {
    if (r.t < startT || r.t > endT) continue;
    if (dayList.length === 0 || dayList[dayList.length - 1] !== r.t) dayList.push(r.t);
  }
  const idxOf = new Map<number, number>();
  dayList.forEach((t, i) => idxOf.set(t, i));
  const nDays = dayList.length;

  const zeros = () => new Array<number>(nDays).fill(0);
  const perChannel: Record<MetricKey, Record<string, number[]>> = {
    sessions: {},
    users: {},
    conversions: {},
    revenue: {},
  };
  for (const id of channels) {
    perChannel.sessions[id] = zeros();
    perChannel.users[id] = zeros();
    perChannel.conversions[id] = zeros();
    perChannel.revenue[id] = zeros();
  }
  const sparkSessions = zeros();
  const sparkUsers = zeros();
  const sparkRevenue = zeros();
  const sparkConvs = zeros();

  const aggMap = new Map<ChannelId, ChannelAgg>();
  for (const id of channels) {
    aggMap.set(id, { meta: CHANNEL_MAP[id], sessions: 0, users: 0, conversions: 0, revenue: 0, rate: 0, share: 0 });
  }
  const deviceSum: Record<DeviceId, number> = { desktop: 0, mobile: 0, tablet: 0 };

  for (const r of DAILY) {
    if (r.t < prevStart || r.t >= endExclusive) continue;
    if (!selected.has(r.channel)) continue;
    const target = r.t >= startT ? totals : prev;
    target.sessions += r.sessions;
    target.users += r.users;
    target.conversions += r.conversions;
    target.revenue += r.revenue;
    if (r.t < startT) continue;
    const di = idxOf.get(r.t);
    if (di === undefined) continue;
    sparkSessions[di] += r.sessions;
    sparkUsers[di] += r.users;
    sparkRevenue[di] += r.revenue;
    sparkConvs[di] += r.conversions;
    perChannel.sessions[r.channel][di] += r.sessions;
    perChannel.users[r.channel][di] += r.users;
    perChannel.conversions[r.channel][di] += r.conversions;
    perChannel.revenue[r.channel][di] += r.revenue;
    deviceSum.desktop += r.desktop;
    deviceSum.mobile += r.mobile;
    deviceSum.tablet += r.tablet;
    const agg = aggMap.get(r.channel)!;
    agg.sessions += r.sessions;
    agg.users += r.users;
    agg.conversions += r.conversions;
    agg.revenue += r.revenue;
  }

  totals.rate = totals.sessions ? (totals.conversions / totals.sessions) * 100 : 0;
  prev.rate = prev.sessions ? (prev.conversions / prev.sessions) * 100 : 0;
  const sparkRate = sparkSessions.map((s, i) => (s ? (sparkConvs[i] / s) * 100 : 0));

  const rowsByMetric: Record<MetricKey, ChartRow[]> = { sessions: [], users: [], conversions: [], revenue: [] };
  (Object.keys(rowsByMetric) as MetricKey[]).forEach((m) => {
    rowsByMetric[m] = dayList.map((t, i) => {
      const row: ChartRow = { label: fmtDate(t), t };
      for (const id of channels) row[id] = perChannel[m][id][i];
      return row;
    });
  });

  const channelAgg = [...aggMap.values()].map((a) => ({
    ...a,
    rate: a.sessions ? (a.conversions / a.sessions) * 100 : 0,
    share: totals.sessions ? (a.sessions / totals.sessions) * 100 : 0,
  }));

  const deviceTotal = deviceSum.desktop + deviceSum.mobile + deviceSum.tablet || 1;
  const devices: DeviceAgg[] = DEVICES.map((d) => ({
    ...d,
    value: deviceSum[d.id],
    pct: (deviceSum[d.id] / deviceTotal) * 100,
  }));

  const rows = ROWS.filter((r) => r.t >= startT && r.t < endExclusive && selected.has(r.channel)).sort(
    (a, b) => b.t - a.t
  );

  return {
    days: nDays,
    totals,
    prev,
    spark: { sessions: sparkSessions, users: sparkUsers, rate: sparkRate, revenue: sparkRevenue },
    rowsByMetric,
    channelAgg,
    devices,
    rows,
  };
}

export function useAnalytics(startT: number, endT: number, channels: ChannelId[]): AnalyticsResult {
  return useMemo(() => compute(startT, endT, channels), [startT, endT, channels]);
}

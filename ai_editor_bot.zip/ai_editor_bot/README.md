# Multi-Agent AI Code Editor Bot

টেলিগ্রাম থেকে `/edit <instructions>` দিলে একটা multi-stage AI pipeline
আপনার গিট রিপোতে কোড খুঁজে বের করে, এডিট করে, নিজে নিজে চেক করে, তারপর
নতুন branch-এ push করে।

## পাইপলাইন

```
git pull
   │
   ▼
Locator agent  ── কোন ফাইল(গুলো) সমস্যার সাথে সম্পর্কিত হতে পারে (blocklist বাদ দিয়ে)
   │
   ▼
Diagnosis agent ── candidate ফাইল + তাদের import করা সংশ্লিষ্ট ফাইল পড়ে root cause বের করে,
   │                চূড়ান্ত target file list ঠিক করে (একাধিক ফাইল হতে পারে)
   ▼
Planning agent ── প্রতিটা ফাইলের জন্য নির্দিষ্ট, একে অপরের সাথে সামঞ্জস্যপূর্ণ instruction বানায়
   │
   ▼
প্রতিটা target file-এর জন্য (retry loop, max ৩ বার):
   Implementation agent ── ছোট ফাইলে পুরো রিরাইট, বড় ফাইলে (>১৫০ লাইন) minimal diff
   │                        (diff apply ব্যর্থ হলে automatic fallback: full rewrite)
   ▼
   Deterministic syntax check ── py_compile / node --check / php -l / json.loads
   ▼
   Dual independent AI reviewer ── দুইজন আলাদাভাবে bug/logic চেক করে
   ▼
   Secret scanner ── hardcoded API key/token/password ধরা পড়লে push ব্লক
   │
   ▼ (সব ফাইল পাস করলে)
Final approval agent ── পুরো changeset একসাথে দেখে APPROVE/REJECT
   │
   ▼
নতুন branch তৈরি ── ai-edit-<timestamp>
   │
   ▼
(config অনুযায়ী) Telegram-এ ✅ Push / ❌ বাদ দাও বাটন ── অথবা auto-push
```

## ইনস্টল

```bash
pip install -r requirements.txt
```

## কনফিগারেশন

**Secrets (environment variable-এ, কোথাও ফাইলে লিখবেন না):**

```bash
export TELEGRAM_BOT_TOKEN="..."
export GEMINI_API_KEYS="key1,key2,key3,key4,key5,key6,key7,key8,key9,key10"
export ALLOWED_USER_IDS="123456789"     # আপনার টেলিগ্রাম user id, কমা দিয়ে একাধিক দেওয়া যায়
export REPO_PATH="/home/you/projects/myrepo"   # চাইলে config.yaml-এও দেওয়া যায়
```

**বাকি সব সেটিং `config.yaml`-এ** — default branch-এর নাম, retry সংখ্যা,
কোন মডেল কোন স্টেজে, blocklist ফাইল প্যাটার্ন, push confirmation চালু/বন্ধ
ইত্যাদি। কোড না ছুঁয়ে এখান থেকেই আচরণ বদলাতে পারবেন।

## চালানো

```bash
python bot.py
```

টেলিগ্রামে:
```
/edit navbar মোবাইলে ভেঙে যাচ্ছে, ঠিক করো
/history
/undo
```

## নিরাপত্তা — যা বিল্ট-ইন আছে

- **অনুমোদিত ইউজার চেক** — `ALLOWED_USER_IDS` ছাড়া অন্য কেউ কমান্ড চালাতে পারবে না
- **Sensitive file blocklist** — `.env`, `*.pem`, `*.key`, secrets ফাইল কখনো এডিট হবে না
- **Secret scanner** — hardcoded key/token/password ধরা পড়লে push সম্পূর্ণ বন্ধ
- **সরাসরি main-এ push হয় না** — সবসময় নতুন branch
- **push confirmation** — default-এ চালু, বাটনে চেপে approve করতে হবে (চাইলে config-এ বন্ধ করা যায়)
- **Audit log** — প্রতিটা রান SQLite-এ (`runs.db`) লগ হয়, `/history` দিয়ে দেখা যায়
- **/undo** — শেষ push হওয়া branch এক কমান্ডে local+remote থেকে মুছে ফেলা যায়

## সীমাবদ্ধতা (যা জানা দরকার)

- এখনো কোনো real automated test suite নেই বলে "টেস্টিং" স্টেজটা আসলে
  deterministic syntax check + দুইজন AI reviewer দিয়ে করা — এটা প্রকৃত
  ইউনিট টেস্টের বিকল্প না, শুধু best-effort।
- Diff apply করার জন্য সিস্টেমে `patch` কমান্ড থাকতে হবে (বেশিরভাগ
  Linux/Mac-এ আগে থেকেই থাকে); না থাকলে automatically full-rewrite মোডে চলে যাবে।
- একই রিপোতে একসাথে একাধিক `/edit` চললে git working copy শেয়ার্ড
  থাকায় সেগুলো ভেতরে ভেতরে সিরিয়ালি (একটার পর একটা) চলবে, যদিও বট নিজে
  ব্লক হবে না।

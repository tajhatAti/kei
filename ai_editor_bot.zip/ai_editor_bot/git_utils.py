"""
সব git অপারেশন এখানে — pull, branch তৈরি, commit, push, আর /undo-এর জন্য
branch delete (local + remote)।
"""

import os
import subprocess
import time

from config import CFG


def run_git(args):
    result = subprocess.run(["git"] + args, cwd=CFG.repo_path, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed:\n{result.stderr.strip()}")
    return result.stdout.strip()


def sync_default_branch():
    run_git(["checkout", CFG.default_branch])
    run_git(["pull"])


def create_new_branch(prefix="ai-edit"):
    branch_name = f"{prefix}-{int(time.time())}"
    run_git(["checkout", "-b", branch_name])
    return branch_name


def commit_all(files, message):
    for f in files:
        run_git(["add", f])
    run_git(["commit", "-m", message])


def push_branch(branch_name):
    run_git(["push", "-u", "origin", branch_name])


def discard_branch(branch_name):
    """push হয়নি এমন একটা branch বাতিল করে local working copy default branch-এ ফেরায়।"""
    run_git(["checkout", CFG.default_branch])
    run_git(["branch", "-D", branch_name])


def undo_pushed_branch(branch_name):
    """ইতিমধ্যে push হওয়া একটা branch local + remote দুই জায়গা থেকেই মুছে দেয়।"""
    run_git(["checkout", CFG.default_branch])
    try:
        run_git(["push", "origin", "--delete", branch_name])
    except RuntimeError:
        pass  # রিমোটে না থাকলেও সমস্যা না, লোকাল ডিলিট চালিয়ে যাই
    run_git(["branch", "-D", branch_name])


def build_file_list():
    file_list = []
    for root, dirs, files in os.walk(CFG.repo_path):
        dirs[:] = [d for d in dirs if d not in CFG.ignore_dirs and not d.startswith(".")]
        for f in files:
            rel = os.path.relpath(os.path.join(root, f), CFG.repo_path).replace(os.sep, "/")
            file_list.append(rel)
    return sorted(file_list)


def read_file(rel_path):
    with open(os.path.join(CFG.repo_path, rel_path), "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def write_file(rel_path, content):
    full_path = os.path.join(CFG.repo_path, rel_path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(content)
